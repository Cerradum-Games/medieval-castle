using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    Rigidbody2D rb;
    Vector2 vel;
    public Transform floorCollider;
    public LayerMask floorLayer; // Adicionada aqui
    public Transform skin;
    public int comboNumber;
    public float comboTime;
    public float dashTime;
    [SerializeField] float speed;
    [SerializeField] float jumpPower;
    [SerializeField] float dashPower;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        comboTime = 0;
    }
    void Update()
    {
        // character actions in game
        move();
        jump();
        dash();
        attack();

        // Irá desligar o PlayerController caso o personagem morra
        if(GetComponent<Character>().life <= 0)
        {
            this.enabled = false;
        }     
    }

    private void FixedUpdate()
    {
        rb.linearVelocity = vel;
    }

    // ------------------------------------------------------------------------------------------------------------------ \\
    private void move()
    {
        vel = new Vector2(Input.GetAxisRaw("Horizontal") * speed, rb.linearVelocity.y);

        if(Input.GetAxisRaw("Horizontal") != 0)
        {
            skin.localScale = new Vector3((Input.GetAxisRaw("Horizontal")) * 5.6f, 5.6f, 5.6f);
            skin.GetComponent<Animator>().SetBool("PlayerRun", true);
        }
        else
        {
            skin.GetComponent<Animator>().SetBool("PlayerRun", false);
        }
    }

    private void jump()
    {
        bool canJump = Physics2D.OverlapCircle(floorCollider.position, 1f, floorLayer);
        
        if (Input.GetButtonDown("Jump") && floorCollider.GetComponent<FloorCollider>().canJump == true)
        {
            skin.GetComponent<Animator>().Play("PlayerJump", -1);
            rb.linearVelocity = Vector2.zero;
            floorCollider.GetComponent<FloorCollider>().canJump = true;
            rb.AddForce(new Vector2(250f, jumpPower));
        }
    }

    private void dash()
    {
        // Habilita o dash
        dashTime = dashTime + Time.deltaTime;
        if(Input.GetButtonDown("Fire2") && dashTime > 1)
        {
            dashTime = 0;
            skin.GetComponent<Animator>().Play("Dash", -1);
            rb.linearVelocity = Vector2.zero;
            rb.AddForce(new Vector2(skin.localScale.x * dashPower, 0));
        }
    }

    private void attack()
    {
        comboTime = comboTime + Time.deltaTime;
        if(Input.GetButtonDown("Fire1") && comboTime > 0.5f) 
        {
            comboNumber++;
            if(comboNumber > 2)
            {
                comboNumber = 1;    
            }
            comboTime = 0;
            skin.GetComponent<Animator>().Play("Attack01" + comboNumber, -1);
        }
        if(comboTime >= 1)
        {
            comboNumber = 0;
        }   
    }

    // ------------------------------------------------------------------------------------------------------------------ \\
}